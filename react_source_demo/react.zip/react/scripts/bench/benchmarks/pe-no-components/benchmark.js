(function() {
  'use strict';

  var ReactImage0 = function(x) {
    if (x === 0) {
      return React.createElement('i', {
        alt: '',
        className: '_3-99 img sp_i534r85sjIn sx_538591',
        src: null,
      });
    }
    if (x === 15) {
      return React.createElement('i', {
        className: '_3ut_ img sp_i534r85sjIn sx_e8ac93',
        src: null,
        alt: '',
      });
    }
    if (x === 22) {
      return React.createElement('i', {
        alt: '',
        className: '_3-8_ img sp_i534r85sjIn sx_7b15bc',
        src: null,
      });
    }
    if (x === 29) {
      return React.createElement('i', {
        className: '_1m1s _4540 _p img sp_i534r85sjIn sx_f40b1c',
        src: null,
        alt: '',
      });
    }
    if (x === 42) {
      return React.createElement(
        'i',
        {
          alt: 'Warning',
          className: '_585p img sp_i534r85sjIn sx_20273d',
          src: null,
        },
        React.createElement('u', null, 'Warning')
      );
    }
    if (x === 67) {
      return React.createElement('i', {
        alt: '',
        className: '_3-8_ img sp_i534r85sjIn sx_b5d079',
        src: null,
      });
    }
    if (x === 70) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_29f8c9',
      });
    }
    if (x === 76) {
      return React.createElement('i', {
        alt: '',
        className: '_3-8_ img sp_i534r85sjIn sx_ef6a9c',
        src: null,
      });
    }
    if (x === 79) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_6f8c43',
      });
    }
    if (x === 88) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_e94a2d',
      });
    }
    if (x === 91) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_7ed7d4',
      });
    }
    if (x === 94) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_930440',
      });
    }
    if (x === 98) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_750c83',
      });
    }
    if (x === 108) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_73c1bb',
      });
    }
    if (x === 111) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_29f28d',
      });
    }
    if (x === 126) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: '_3-8_ img sp_i534r85sjIn sx_91c59e',
      });
    }
    if (x === 127) {
      return React.createElement('i', {
        alt: '',
        className: '_3-99 img sp_i534r85sjIn sx_538591',
        src: null,
      });
    }
    if (x === 134) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: '_3-8_ img sp_i534r85sjIn sx_c8eb75',
      });
    }
    if (x === 135) {
      return React.createElement('i', {
        alt: '',
        className: '_3-99 img sp_i534r85sjIn sx_538591',
        src: null,
      });
    }
    if (x === 148) {
      return React.createElement('i', {
        className: '_3yz6 _5whs img sp_i534r85sjIn sx_896996',
        src: null,
        alt: '',
      });
    }
    if (x === 152) {
      return React.createElement('i', {
        className: '_5b5p _4gem img sp_i534r85sjIn sx_896996',
        src: null,
        alt: '',
      });
    }
    if (x === 153) {
      return React.createElement('i', {
        className: '_541d img sp_i534r85sjIn sx_2f396a',
        src: null,
        alt: '',
      });
    }
    if (x === 160) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_31d9b0',
      });
    }
    if (x === 177) {
      return React.createElement('i', {
        alt: '',
        className: '_3-99 img sp_i534r85sjIn sx_2c18b7',
        src: null,
      });
    }
    if (x === 186) {
      return React.createElement('i', {
        src: null,
        alt: '',
        className: 'img sp_i534r85sjIn sx_0a681f',
      });
    }
    if (x === 195) {
      return React.createElement('i', {
        className: '_1-lx img sp_OkER5ktbEyg sx_b369b4',
        src: null,
        alt: '',
      });
    }
    if (x === 198) {
      return React.createElement('i', {
        className: '_1-lx img sp_i534r85sjIn sx_96948e',
        src: null,
        alt: '',
      });
    }
    if (x === 237) {
      return React.createElement('i', {
        className: '_541d img sp_i534r85sjIn sx_2f396a',
        src: null,
        alt: '',
      });
    }
    if (x === 266) {
      return React.createElement('i', {
        alt: '',
        className: '_3-99 img sp_i534r85sjIn sx_538591',
        src: null,
      });
    }
    if (x === 314) {
      return React.createElement('i', {
        className: '_1cie _1cif img sp_i534r85sjIn sx_6e6820',
        src: null,
        alt: '',
      });
    }
    if (x === 345) {
      return React.createElement('i', {
        className: '_1cie img sp_i534r85sjIn sx_e896cf',
        src: null,
        alt: '',
      });
    }
    if (x === 351) {
      return React.createElement('i', {
        className: '_1cie img sp_i534r85sjIn sx_38fed8',
        src: null,
        alt: '',
      });
    }
  };

  var AbstractLink1 = function(x) {
    if (x === 1) {
      return React.createElement(
        'a',
        {
          className: '_387r _55pi _2agf _4jy0 _4jy4 _517h _51sy _42ft',
          style: {width: 250, maxWidth: '250px'},
          disabled: null,
          label: null,
          href: '#',
          rel: undefined,
          onClick: function() {},
        },
        null,
        React.createElement(
          'span',
          {className: '_55pe', style: {maxWidth: '236px'}},
          null,
          React.createElement(
            'span',
            null,
            React.createElement('span', {className: '_48u-'}, 'Account:'),
            ' ',
            'Dick Madanson (10149999073643408)'
          )
        ),
        ReactImage0(0)
      );
    }
    if (x === 43) {
      return React.createElement(
        'a',
        {
          className: '_585q _50zy _50-0 _50z- _5upp _42ft',
          size: 'medium',
          type: null,
          title: 'Remove',
          'data-hover': undefined,
          'data-tooltip-alignh': undefined,
          'data-tooltip-content': undefined,
          disabled: null,
          label: null,
          href: '#',
          rel: undefined,
          onClick: function() {},
        },
        undefined,
        'Remove',
        undefined
      );
    }
    if (x === 49) {
      return React.createElement(
        'a',
        {
          target: '_blank',
          href: '/ads/manage/billing.php?act=10149999073643408',
          rel: undefined,
          onClick: function() {},
        },
        XUIText29(48)
      );
    }
    if (x === 128) {
      return React.createElement(
        'a',
        {
          className: ' _5bbf _55pi _2agf _4jy0 _4jy4 _517h _51sy _42ft',
          style: {maxWidth: '200px'},
          disabled: null,
          label: null,
          href: '#',
          rel: undefined,
          onClick: function() {},
        },
        null,
        React.createElement(
          'span',
          {className: '_55pe', style: {maxWidth: '186px'}},
          ReactImage0(126),
          'Search'
        ),
        ReactImage0(127)
      );
    }
    if (x === 136) {
      return React.createElement(
        'a',
        {
          className: ' _5bbf _55pi _2agf _4jy0 _4jy4 _517h _51sy _42ft',
          style: {maxWidth: '200px'},
          disabled: null,
          label: null,
          href: '#',
          rel: undefined,
          onClick: function() {},
        },
        null,
        React.createElement(
          'span',
          {className: '_55pe', style: {maxWidth: '186px'}},
          ReactImage0(134),
          'Filters'
        ),
        ReactImage0(135)
      );
    }
    if (x === 178) {
      return React.createElement(
        'a',
        {
          className: '_1_-t _1_-v _42ft',
          disabled: null,
          height: 'medium',
          role: 'button',
          label: null,
          href: '#',
          rel: undefined,
          onClick: function() {},
        },
        undefined,
        'Lifetime',
        ReactImage0(177)
      );
    }
    if (x === 207) {
      return React.createElement(
        'a',
        {href: '#', rel: undefined, onClick: function() {}},
        'Create Ad Set'
      );
    }
    if (x === 209) {
      return React.createElement(
        'a',
        {href: '#', rel: undefined, onClick: function() {}},
        'View Ad Set'
      );
    }
    if (x === 241) {
      return React.createElement(
        'a',
        {href: '#', rel: undefined, onClick: function() {}},
        'Set a Limit'
      );
    }
    if (x === 267) {
      return React.createElement(
        'a',
        {
          className: '_p _55pi _2agf _4jy0 _4jy3 _517h _51sy _42ft',
          style: {maxWidth: '200px'},
          disabled: null,
          label: null,
          href: '#',
          rel: undefined,
          onClick: function() {},
        },
        null,
        React.createElement(
          'span',
          {className: '_55pe', style: {maxWidth: '186px'}},
          null,
          'Links'
        ),
        ReactImage0(266)
      );
    }
  };

  var Link2 = function(x) {
    if (x === 2) {
      return AbstractLink1(1);
    }
    if (x === 44) {
      return AbstractLink1(43);
    }
    if (x === 50) {
      return AbstractLink1(49);
    }
    if (x === 129) {
      return AbstractLink1(128);
    }
    if (x === 137) {
      return AbstractLink1(136);
    }
    if (x === 179) {
      return AbstractLink1(178);
    }
    if (x === 208) {
      return AbstractLink1(107);
    }
    if (x === 210) {
      return AbstractLink1(209);
    }
    if (x === 242) {
      return AbstractLink1(241);
    }
    if (x === 268) {
      return AbstractLink1(267);
    }
  };

  var AbstractButton3 = function(x) {
    if (x === 3) {
      return Link2(2);
    }
    if (x === 20) {
      return React.createElement(
        'button',
        {
          className: '_5n7z _4jy0 _4jy4 _517h _51sy _42ft',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        undefined,
        'Discard Changes',
        undefined
      );
    }
    if (x === 23) {
      return React.createElement(
        'button',
        {
          className: '_5n7z _2yak _4lj- _4jy0 _4jy4 _517h _51sy _42ft _42fr',
          disabled: true,
          onClick: function() {},
          'data-tooltip-content': 'You have no changes to publish',
          'data-hover': 'tooltip',
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(22),
        'Review Changes',
        undefined
      );
    }
    if (x === 45) {
      return Link2(44);
    }
    if (x === 68) {
      return React.createElement(
        'button',
        {
          className: '_u_k _4jy0 _4jy4 _517h _51sy _42ft',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(67),
        'Create Campaign',
        undefined
      );
    }
    if (x === 71) {
      return React.createElement(
        'button',
        {
          className: '_u_k _3qx6 _p _4jy0 _4jy4 _517h _51sy _42ft',
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(70),
        undefined,
        undefined
      );
    }
    if (x === 77) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Edit',
          'data-tooltip-content': 'Edit Campaigns (Ctrl+U)',
          'data-hover': 'tooltip',
          className: '_d2_ _u_k noMargin _4jy0 _4jy4 _517h _51sy _42ft',
          disabled: false,
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(76),
        'Edit',
        undefined
      );
    }
    if (x === 80) {
      return React.createElement(
        'button',
        {
          className: '_u_k _3qx6 _p _4jy0 _4jy4 _517h _51sy _42ft',
          disabled: false,
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(79),
        undefined,
        undefined
      );
    }
    if (x === 89) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Revert',
          className: '_u_k _4jy0 _4jy4 _517h _51sy _42ft _42fr',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'Revert',
          disabled: true,
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(88),
        undefined,
        undefined
      );
    }
    if (x === 92) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Delete',
          className: '_u_k _4jy0 _4jy4 _517h _51sy _42ft',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'Delete',
          disabled: false,
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(91),
        undefined,
        undefined
      );
    }
    if (x === 95) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Duplicate',
          className: '_u_k _4jy0 _4jy4 _517h _51sy _42ft',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'Duplicate',
          disabled: false,
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(94),
        undefined,
        undefined
      );
    }
    if (x === 99) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Export & Import',
          className: '_u_k noMargin _p _4jy0 _4jy4 _517h _51sy _42ft',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'Export & Import',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(98),
        undefined,
        undefined
      );
    }
    if (x === 109) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Create Report',
          className: '_u_k _5n7z _4jy0 _4jy4 _517h _51sy _42ft',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'Create Report',
          disabled: false,
          style: {boxSizing: 'border-box', height: '28px', width: '48px'},
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(108),
        undefined,
        undefined
      );
    }
    if (x === 112) {
      return React.createElement(
        'button',
        {
          'aria-label': 'Campaign Tags',
          className: ' _5uy7 _4jy0 _4jy4 _517h _51sy _42ft',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'Campaign Tags',
          disabled: false,
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(111),
        undefined,
        undefined
      );
    }
    if (x === 130) {
      return Link2(129);
    }
    if (x === 138) {
      return Link2(137);
    }
    if (x === 149) {
      return React.createElement(
        'button',
        {
          className: '_3yz9 _1t-2 _50z- _50zy _50zz _50z- _5upp _42ft',
          size: 'small',
          onClick: function() {},
          type: 'button',
          title: 'Remove',
          'data-hover': undefined,
          'data-tooltip-alignh': undefined,
          'data-tooltip-content': undefined,
          label: null,
        },
        undefined,
        'Remove',
        undefined
      );
    }
    if (x === 156) {
      return React.createElement(
        'button',
        {
          className: '_5b5u _5b5v _4jy0 _4jy3 _517h _51sy _42ft',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        undefined,
        'Apply',
        undefined
      );
    }
    if (x === 161) {
      return React.createElement(
        'button',
        {
          className: '_1wdf _4jy0 _517i _517h _51sy _42ft',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(160),
        undefined,
        undefined
      );
    }
    if (x === 180) {
      return Link2(179);
    }
    if (x === 187) {
      return React.createElement(
        'button',
        {
          'aria-label': 'List Settings',
          className: '_u_k _3c5o _1-r0 _4jy0 _4jy4 _517h _51sy _42ft',
          'data-hover': 'tooltip',
          'data-tooltip-content': 'List Settings',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        ReactImage0(186),
        undefined,
        undefined
      );
    }
    if (x === 269) {
      return Link2(268);
    }
    if (x === 303) {
      return React.createElement(
        'button',
        {
          className: '_tm3 _tm6 _tm7 _4jy0 _4jy6 _517h _51sy _42ft',
          'data-tooltip-position': 'right',
          'data-tooltip-content': 'Campaigns',
          'data-hover': 'tooltip',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        undefined,
        React.createElement(
          'div',
          null,
          React.createElement('div', {className: '_tma'}),
          React.createElement('div', {className: '_tm8'}),
          React.createElement('div', {className: '_tm9'}, 1)
        ),
        undefined
      );
    }
    if (x === 305) {
      return React.createElement(
        'button',
        {
          className: '_tm4 _tm6 _4jy0 _4jy6 _517h _51sy _42ft',
          'data-tooltip-position': 'right',
          'data-tooltip-content': 'Ad Sets',
          'data-hover': 'tooltip',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        undefined,
        React.createElement(
          'div',
          null,
          React.createElement('div', {className: '_tma'}),
          React.createElement('div', {className: '_tm8'}),
          React.createElement('div', {className: '_tm9'}, 1)
        ),
        undefined
      );
    }
    if (x === 307) {
      return React.createElement(
        'button',
        {
          className: '_tm5 _tm6 _4jy0 _4jy6 _517h _51sy _42ft',
          'data-tooltip-position': 'right',
          'data-tooltip-content': 'Ads',
          'data-hover': 'tooltip',
          onClick: function() {},
          label: null,
          type: 'submit',
          value: '1',
        },
        undefined,
        React.createElement(
          'div',
          null,
          React.createElement('div', {className: '_tma'}),
          React.createElement('div', {className: '_tm8'}),
          React.createElement('div', {className: '_tm9'}, 1)
        ),
        undefined
      );
    }
  };

  var XUIButton4 = function(x) {
    if (x === 4) {
      return AbstractButton3(3);
    }
    if (x === 21) {
      return AbstractButton3(20);
    }
    if (x === 24) {
      return AbstractButton3(23);
    }
    if (x === 69) {
      return AbstractButton3(68);
    }
    if (x === 72) {
      return AbstractButton3(71);
    }
    if (x === 78) {
      return AbstractButton3(77);
    }
    if (x === 81) {
      return AbstractButton3(80);
    }
    if (x === 90) {
      return AbstractButton3(89);
    }
    if (x === 93) {
      return AbstractButton3(92);
    }
    if (x === 96) {
      return AbstractButton3(95);
    }
    if (x === 100) {
      return AbstractButton3(99);
    }
    if (x === 110) {
      return AbstractButton3(109);
    }
    if (x === 113) {
      return AbstractButton3(112);
    }
    if (x === 131) {
      return AbstractButton3(130);
    }
    if (x === 139) {
      return AbstractButton3(138);
    }
    if (x === 157) {
      return AbstractButton3(156);
    }
    if (x === 162) {
      return AbstractButton3(161);
    }
    if (x === 188) {
      return AbstractButton3(187);
    }
    if (x === 270) {
      return AbstractButton3(269);
    }
    if (x === 304) {
      return AbstractButton3(303);
    }
    if (x === 306) {
      return AbstractButton3(305);
    }
    if (x === 308) {
      return AbstractButton3(307);
    }
  };

  var AbstractPopoverButton5 = function(x) {
    if (x === 5) {
      return XUIButton4(4);
    }
    if (x === 132) {
      return XUIButton4(131);
    }
    if (x === 140) {
      return XUIButton4(139);
    }
    if (x === 271) {
      return XUIButton4(270);
    }
  };

  var ReactXUIPopoverButton6 = function(x) {
    if (x === 6) {
      return AbstractPopoverButton5(5);
    }
    if (x === 133) {
      return AbstractPopoverButton5(132);
    }
    if (x === 141) {
      return AbstractPopoverButton5(140);
    }
    if (x === 272) {
      return AbstractPopoverButton5(271);
    }
  };

  var BIGAdAccountSelector7 = function(x) {
    if (x === 7) {
      return React.createElement('div', null, ReactXUIPopoverButton6(6), null);
    }
  };

  var FluxContainer_AdsPEBIGAdAccountSelectorContainer_8 = function(x) {
    if (x === 8) {
      return BIGAdAccountSelector7(7);
    }
  };

  var ErrorBoundary9 = function(x) {
    if (x === 9) {
      return FluxContainer_AdsPEBIGAdAccountSelectorContainer_8(8);
    }
    if (x === 13) {
      return FluxContainer_AdsPENavigationBarContainer_12(12);
    }
    if (x === 27) {
      return FluxContainer_AdsPEPublishButtonContainer_18(26);
    }
    if (x === 32) {
      return ReactPopoverMenu20(31);
    }
    if (x === 38) {
      return AdsPEResetDialog24(37);
    }
    if (x === 57) {
      return FluxContainer_AdsPETopErrorContainer_35(56);
    }
    if (x === 60) {
      return FluxContainer_AdsGuidanceChannel_36(59);
    }
    if (x === 64) {
      return FluxContainer_AdsBulkEditDialogContainer_38(63);
    }
    if (x === 124) {
      return AdsPECampaignGroupToolbarContainer57(123);
    }
    if (x === 170) {
      return AdsPEFilterContainer72(169);
    }
    if (x === 175) {
      return AdsPETablePagerContainer75(174);
    }
    if (x === 193) {
      return AdsPEStatRangeContainer81(192);
    }
    if (x === 301) {
      return FluxContainer_AdsPEMultiTabDrawerContainer_137(300);
    }
    if (x === 311) {
      return AdsPEOrganizerContainer139(310);
    }
    if (x === 471) {
      return AdsPECampaignGroupTableContainer159(470);
    }
    if (x === 475) {
      return AdsPEContentContainer161(474);
    }
  };

  var AdsErrorBoundary10 = function(x) {
    if (x === 10) {
      return ErrorBoundary9(9);
    }
    if (x === 14) {
      return ErrorBoundary9(13);
    }
    if (x === 28) {
      return ErrorBoundary9(27);
    }
    if (x === 33) {
      return ErrorBoundary9(32);
    }
    if (x === 39) {
      return ErrorBoundary9(38);
    }
    if (x === 58) {
      return ErrorBoundary9(57);
    }
    if (x === 61) {
      return ErrorBoundary9(60);
    }
    if (x === 65) {
      return ErrorBoundary9(64);
    }
    if (x === 125) {
      return ErrorBoundary9(124);
    }
    if (x === 171) {
      return ErrorBoundary9(170);
    }
    if (x === 176) {
      return ErrorBoundary9(175);
    }
    if (x === 194) {
      return ErrorBoundary9(193);
    }
    if (x === 302) {
      return ErrorBoundary9(301);
    }
    if (x === 312) {
      return ErrorBoundary9(311);
    }
    if (x === 472) {
      return ErrorBoundary9(471);
    }
    if (x === 476) {
      return ErrorBoundary9(475);
    }
  };

  var AdsPENavigationBar11 = function(x) {
    if (x === 11) {
      return React.createElement('div', {className: '_4t_9'});
    }
  };

  var FluxContainer_AdsPENavigationBarContainer_12 = function(x) {
    if (x === 12) {
      return AdsPENavigationBar11(11);
    }
  };

  var AdsPEDraftSyncStatus13 = function(x) {
    if (x === 16) {
      return React.createElement(
        'div',
        {className: '_3ut-', onClick: function() {}},
        React.createElement('span', {className: '_3uu0'}, ReactImage0(15))
      );
    }
  };

  var FluxContainer_AdsPEDraftSyncStatusContainer_14 = function(x) {
    if (x === 17) {
      return AdsPEDraftSyncStatus13(16);
    }
  };

  var AdsPEDraftErrorsStatus15 = function(x) {
    if (x === 18) {
      return null;
    }
  };

  var FluxContainer_viewFn_16 = function(x) {
    if (x === 19) {
      return AdsPEDraftErrorsStatus15(18);
    }
  };

  var AdsPEPublishButton17 = function(x) {
    if (x === 25) {
      return React.createElement(
        'div',
        {className: '_5533'},
        FluxContainer_AdsPEDraftSyncStatusContainer_14(17),
        FluxContainer_viewFn_16(19),
        null,
        XUIButton4(21, 'discard'),
        XUIButton4(24)
      );
    }
  };

  var FluxContainer_AdsPEPublishButtonContainer_18 = function(x) {
    if (x === 26) {
      return AdsPEPublishButton17(25);
    }
  };

  var InlineBlock19 = function(x) {
    if (x === 30) {
      return React.createElement(
        'div',
        {className: 'uiPopover _6a _6b', disabled: null},
        ReactImage0(29)
      );
    }
    if (x === 73) {
      return React.createElement(
        'div',
        {className: 'uiPopover _6a _6b', disabled: null},
        XUIButton4(72)
      );
    }
    if (x === 82) {
      return React.createElement(
        'div',
        {className: '_1nwm uiPopover _6a _6b', disabled: null},
        XUIButton4(81)
      );
    }
    if (x === 101) {
      return React.createElement(
        'div',
        {size: 'large', className: 'uiPopover _6a _6b', disabled: null},
        XUIButton4(100)
      );
    }
    if (x === 273) {
      return React.createElement(
        'div',
        {
          className: '_3-90 uiPopover _6a _6b',
          style: {marginTop: 2},
          disabled: null,
        },
        ReactXUIPopoverButton6(272)
      );
    }
  };

  var ReactPopoverMenu20 = function(x) {
    if (x === 31) {
      return InlineBlock19(30);
    }
    if (x === 74) {
      return InlineBlock19(73);
    }
    if (x === 83) {
      return InlineBlock19(82);
    }
    if (x === 102) {
      return InlineBlock19(101);
    }
    if (x === 274) {
      return InlineBlock19(273);
    }
  };

  var LeftRight21 = function(x) {
    if (x === 34) {
      return React.createElement(
        'div',
        {className: 'clearfix'},
        React.createElement(
          'div',
          {key: 'left', className: '_ohe lfloat'},
          React.createElement(
            'div',
            {className: '_34_j'},
            React.createElement(
              'div',
              {className: '_34_k'},
              AdsErrorBoundary10(10)
            ),
            React.createElement(
              'div',
              {className: '_2u-6'},
              AdsErrorBoundary10(14)
            )
          )
        ),
        React.createElement(
          'div',
          {key: 'right', className: '_ohf rfloat'},
          React.createElement(
            'div',
            {className: '_34_m'},
            React.createElement(
              'div',
              {key: '0', className: '_5ju2'},
              AdsErrorBoundary10(28)
            ),
            React.createElement(
              'div',
              {key: '1', className: '_5ju2'},
              AdsErrorBoundary10(33)
            )
          )
        )
      );
    }
    if (x === 232) {
      return React.createElement(
        'div',
        {direction: 'left', className: 'clearfix'},
        React.createElement(
          'div',
          {key: 'left', className: '_ohe lfloat'},
          AdsLabeledField104(231)
        ),
        React.createElement(
          'div',
          {key: 'right', className: ''},
          React.createElement(
            'div',
            {className: '_42ef'},
            React.createElement(
              'div',
              {className: '_2oc7'},
              'Clicks to Website'
            )
          )
        )
      );
    }
    if (x === 235) {
      return React.createElement(
        'div',
        {className: '_3-8x clearfix', direction: 'left'},
        React.createElement(
          'div',
          {key: 'left', className: '_ohe lfloat'},
          AdsLabeledField104(234)
        ),
        React.createElement(
          'div',
          {key: 'right', className: ''},
          React.createElement(
            'div',
            {className: '_42ef'},
            React.createElement('div', {className: '_2oc7'}, 'Auction')
          )
        )
      );
    }
    if (x === 245) {
      return React.createElement(
        'div',
        {className: '_3-8y clearfix', direction: 'left'},
        React.createElement(
          'div',
          {key: 'left', className: '_ohe lfloat'},
          AdsLabeledField104(240)
        ),
        React.createElement(
          'div',
          {key: 'right', className: ''},
          React.createElement(
            'div',
            {className: '_42ef'},
            FluxContainer_AdsCampaignGroupSpendCapContainer_107(244)
          )
        )
      );
    }
    if (x === 277) {
      return React.createElement(
        'div',
        {className: '_5dw9 _5dwa clearfix'},
        React.createElement(
          'div',
          {key: 'left', className: '_ohe lfloat'},
          XUICardHeaderTitle100(265)
        ),
        React.createElement(
          'div',
          {key: 'right', className: '_ohf rfloat'},
          FluxContainer_AdsPluginizedLinksMenuContainer_121(276)
        )
      );
    }
  };

  var AdsUnifiedNavigationLocalNav22 = function(x) {
    if (x === 35) {
      return React.createElement('div', {className: '_34_i'}, LeftRight21(34));
    }
  };

  var XUIDialog23 = function(x) {
    if (x === 36) {
      return null;
    }
  };

  var AdsPEResetDialog24 = function(x) {
    if (x === 37) {
      return React.createElement('span', null, XUIDialog23(36));
    }
  };

  var AdsPETopNav25 = function(x) {
    if (x === 40) {
      return React.createElement(
        'div',
        {style: {width: 1306}},
        AdsUnifiedNavigationLocalNav22(35),
        AdsErrorBoundary10(39)
      );
    }
  };

  var FluxContainer_AdsPETopNavContainer_26 = function(x) {
    if (x === 41) {
      return AdsPETopNav25(40);
    }
  };

  var XUIAbstractGlyphButton27 = function(x) {
    if (x === 46) {
      return AbstractButton3(45);
    }
    if (x === 150) {
      return AbstractButton3(149);
    }
  };

  var XUICloseButton28 = function(x) {
    if (x === 47) {
      return XUIAbstractGlyphButton27(46);
    }
    if (x === 151) {
      return XUIAbstractGlyphButton27(150);
    }
  };

  var XUIText29 = function(x) {
    if (x === 48) {
      return React.createElement(
        'span',
        {display: 'inline', className: ' _50f7'},
        'Ads Manager'
      );
    }
    if (x === 205) {
      return React.createElement(
        'span',
        {className: '_2x9f  _50f5 _50f7', display: 'inline'},
        'Editing Campaign'
      );
    }
    if (x === 206) {
      return React.createElement(
        'span',
        {display: 'inline', className: ' _50f5 _50f7'},
        'Test Campaign'
      );
    }
  };

  var XUINotice30 = function(x) {
    if (x === 51) {
      return React.createElement(
        'div',
        {size: 'medium', className: '_585n _585o _2wdd'},
        ReactImage0(42),
        XUICloseButton28(47),
        React.createElement(
          'div',
          {className: '_585r _2i-a _50f4'},
          'Please go to ',
          Link2(50),
          ' to set up a payment method for this ad account.'
        )
      );
    }
  };

  var ReactCSSTransitionGroupChild31 = function(x) {
    if (x === 52) {
      return XUINotice30(51);
    }
  };

  var ReactTransitionGroup32 = function(x) {
    if (x === 53) {
      return React.createElement(
        'span',
        null,
        ReactCSSTransitionGroupChild31(52)
      );
    }
  };

  var ReactCSSTransitionGroup33 = function(x) {
    if (x === 54) {
      return ReactTransitionGroup32(53);
    }
  };

  var AdsPETopError34 = function(x) {
    if (x === 55) {
      return React.createElement(
        'div',
        {className: '_2wdc'},
        ReactCSSTransitionGroup33(54)
      );
    }
  };

  var FluxContainer_AdsPETopErrorContainer_35 = function(x) {
    if (x === 56) {
      return AdsPETopError34(55);
    }
  };

  var FluxContainer_AdsGuidanceChannel_36 = function(x) {
    if (x === 59) {
      return null;
    }
  };

  var ResponsiveBlock37 = function(x) {
    if (x === 62) {
      return React.createElement(
        'div',
        {className: '_4u-c'},
        [AdsErrorBoundary10(58), AdsErrorBoundary10(61)],
        React.createElement(
          'div',
          {key: 'sensor', className: '_4u-f'},
          React.createElement('iframe', {
            'aria-hidden': 'true',
            className: '_1_xb',
            tabIndex: '-1',
          })
        )
      );
    }
    if (x === 469) {
      return React.createElement(
        'div',
        {className: '_4u-c'},
        AdsPEDataTableContainer158(468),
        React.createElement(
          'div',
          {key: 'sensor', className: '_4u-f'},
          React.createElement('iframe', {
            'aria-hidden': 'true',
            className: '_1_xb',
            tabIndex: '-1',
          })
        )
      );
    }
  };

  var FluxContainer_AdsBulkEditDialogContainer_38 = function(x) {
    if (x === 63) {
      return null;
    }
  };

  var Column39 = function(x) {
    if (x === 66) {
      return React.createElement(
        'div',
        {className: '_4bl8 _4bl7'},
        React.createElement(
          'div',
          {className: '_3c5f'},
          null,
          null,
          React.createElement('div', {className: '_3c5i'}),
          null
        )
      );
    }
  };

  var XUIButtonGroup40 = function(x) {
    if (x === 75) {
      return React.createElement(
        'div',
        {className: '_5n7z _51xa'},
        XUIButton4(69),
        ReactPopoverMenu20(74)
      );
    }
    if (x === 84) {
      return React.createElement(
        'div',
        {className: '_5n7z _51xa'},
        XUIButton4(78),
        ReactPopoverMenu20(83)
      );
    }
    if (x === 97) {
      return React.createElement(
        'div',
        {className: '_5n7z _51xa'},
        XUIButton4(90),
        XUIButton4(93),
        XUIButton4(96)
      );
    }
    if (x === 117) {
      return React.createElement(
        'div',
        {className: '_5n7z _51xa'},
        AdsPEExportImportMenuContainer48(107),
        XUIButton4(110),
        AdsPECampaignGroupTagContainer51(116)
      );
    }
  };

  var AdsPEEditToolbarButton41 = function(x) {
    if (x === 85) {
      return XUIButtonGroup40(84);
    }
  };

  var FluxContainer_AdsPEEditCampaignGroupToolbarButtonContainer_42 = function(
    x
  ) {
    if (x === 86) {
      return AdsPEEditToolbarButton41(85);
    }
  };

  var FluxContainer_AdsPEEditToolbarButtonContainer_43 = function(x) {
    if (x === 87) {
      return FluxContainer_AdsPEEditCampaignGroupToolbarButtonContainer_42(86);
    }
  };

  var AdsPEExportImportMenu44 = function(x) {
    if (x === 103) {
      return ReactPopoverMenu20(102);
    }
  };

  var FluxContainer_AdsPECustomizeExportContainer_45 = function(x) {
    if (x === 104) {
      return null;
    }
  };

  var AdsPEExportAsTextDialog46 = function(x) {
    if (x === 105) {
      return null;
    }
  };

  var FluxContainer_AdsPEExportAsTextDialogContainer_47 = function(x) {
    if (x === 106) {
      return AdsPEExportAsTextDialog46(105);
    }
  };

  var AdsPEExportImportMenuContainer48 = function(x) {
    if (x === 107) {
      return React.createElement(
        'span',
        null,
        AdsPEExportImportMenu44(103),
        FluxContainer_AdsPECustomizeExportContainer_45(104),
        FluxContainer_AdsPEExportAsTextDialogContainer_47(106),
        null,
        null
      );
    }
  };

  var Constructor49 = function(x) {
    if (x === 114) {
      return null;
    }
    if (x === 142) {
      return null;
    }
    if (x === 143) {
      return null;
    }
    if (x === 183) {
      return null;
    }
  };

  var TagSelectorPopover50 = function(x) {
    if (x === 115) {
      return React.createElement(
        'span',
        {className: ' _3d6e'},
        XUIButton4(113),
        Constructor49(114)
      );
    }
  };

  var AdsPECampaignGroupTagContainer51 = function(x) {
    if (x === 116) {
      return TagSelectorPopover50(115);
    }
  };

  var AdsRuleToolbarMenu52 = function(x) {
    if (x === 118) {
      return null;
    }
  };

  var FluxContainer_AdsPERuleToolbarMenuContainer_53 = function(x) {
    if (x === 119) {
      return AdsRuleToolbarMenu52(118);
    }
  };

  var FillColumn54 = function(x) {
    if (x === 120) {
      return React.createElement(
        'div',
        {className: '_4bl9'},
        React.createElement(
          'span',
          {className: '_3c5e'},
          React.createElement(
            'span',
            null,
            XUIButtonGroup40(75),
            FluxContainer_AdsPEEditToolbarButtonContainer_43(87),
            null,
            XUIButtonGroup40(97)
          ),
          XUIButtonGroup40(117),
          FluxContainer_AdsPERuleToolbarMenuContainer_53(119)
        )
      );
    }
  };

  var Layout55 = function(x) {
    if (x === 121) {
      return React.createElement(
        'div',
        {className: 'clearfix'},
        Column39(66),
        FillColumn54(120)
      );
    }
  };

  var AdsPEMainPaneToolbar56 = function(x) {
    if (x === 122) {
      return React.createElement(
        'div',
        {className: '_3c5b clearfix'},
        Layout55(121)
      );
    }
  };

  var AdsPECampaignGroupToolbarContainer57 = function(x) {
    if (x === 123) {
      return AdsPEMainPaneToolbar56(122);
    }
  };

  var AdsPEFiltersPopover58 = function(x) {
    if (x === 144) {
      return React.createElement(
        'span',
        {className: '_5b-l  _5bbe'},
        ReactXUIPopoverButton6(133),
        ReactXUIPopoverButton6(141),
        [Constructor49(142), Constructor49(143)]
      );
    }
  };

  var AbstractCheckboxInput59 = function(x) {
    if (x === 145) {
      return React.createElement(
        'label',
        {className: 'uiInputLabelInput _55sg _kv1'},
        React.createElement('input', {
          checked: true,
          disabled: true,
          name: 'filterUnpublished',
          value: 'on',
          onClick: function() {},
          className: null,
          id: 'js_input_label_21',
          type: 'checkbox',
        }),
        React.createElement('span', {
          'data-hover': null,
          'data-tooltip-content': undefined,
        })
      );
    }
    if (x === 336) {
      return React.createElement(
        'label',
        {className: '_4h2r _55sg _kv1'},
        React.createElement('input', {
          checked: undefined,
          onChange: function() {},
          className: null,
          type: 'checkbox',
        }),
        React.createElement('span', {
          'data-hover': null,
          'data-tooltip-content': undefined,
        })
      );
    }
  };

  var XUICheckboxInput60 = function(x) {
    if (x === 146) {
      return AbstractCheckboxInput59(145);
    }
    if (x === 337) {
      return AbstractCheckboxInput59(336);
    }
  };

  var InputLabel61 = function(x) {
    if (x === 147) {
      return React.createElement(
        'div',
        {display: 'block', className: 'uiInputLabel clearfix'},
        XUICheckboxInput60(146),
        React.createElement(
          'label',
          {className: 'uiInputLabelLabel', htmlFor: 'js_input_label_21'},
          'Always show new items'
        )
      );
    }
  };

  var AdsPopoverLink62 = function(x) {
    if (x === 154) {
      return React.createElement(
        'span',
        null,
        React.createElement(
          'span',
          {
            onMouseEnter: function() {},
            onMouseLeave: function() {},
            onMouseUp: undefined,
          },
          React.createElement('span', {className: '_3o_j'}),
          ReactImage0(153)
        ),
        null
      );
    }
    if (x === 238) {
      return React.createElement(
        'span',
        null,
        React.createElement(
          'span',
          {
            onMouseEnter: function() {},
            onMouseLeave: function() {},
            onMouseUp: undefined,
          },
          React.createElement('span', {className: '_3o_j'}),
          ReactImage0(237)
        ),
        null
      );
    }
  };

  var AdsHelpLink63 = function(x) {
    if (x === 155) {
      return AdsPopoverLink62(154);
    }
    if (x === 239) {
      return AdsPopoverLink62(238);
    }
  };

  var BUIFilterTokenInput64 = function(x) {
    if (x === 158) {
      return React.createElement(
        'div',
        {className: '_5b5o _3yz3 _4cld'},
        React.createElement(
          'div',
          {className: '_5b5t _2d2k'},
          ReactImage0(152),
          React.createElement(
            'div',
            {className: '_5b5r'},
            'Campaigns: (1)',
            AdsHelpLink63(155)
          )
        ),
        XUIButton4(157)
      );
    }
  };

  var BUIFilterToken65 = function(x) {
    if (x === 159) {
      return React.createElement(
        'div',
        {className: '_3yz1 _3yz2 _3dad'},
        React.createElement(
          'div',
          {className: '_3yz4', 'aria-hidden': false},
          React.createElement(
            'div',
            {onClick: function() {}, className: '_3yz5'},
            ReactImage0(148),
            React.createElement('div', {className: '_3yz7'}, 'Campaigns:'),
            React.createElement(
              'div',
              {
                className: 'ellipsis _3yz8',
                'data-hover': 'tooltip',
                'data-tooltip-display': 'overflow',
              },
              '(1)'
            )
          ),
          null,
          XUICloseButton28(151)
        ),
        BUIFilterTokenInput64(158)
      );
    }
  };

  var BUIFilterTokenCreateButton66 = function(x) {
    if (x === 163) {
      return React.createElement('div', {className: '_1tc'}, XUIButton4(162));
    }
  };

  var BUIFilterTokenizer67 = function(x) {
    if (x === 164) {
      return React.createElement(
        'div',
        {className: '_5b-m  clearfix'},
        undefined,
        [],
        BUIFilterToken65(159),
        BUIFilterTokenCreateButton66(163),
        null,
        React.createElement('div', {className: '_49u3'})
      );
    }
  };

  var XUIAmbientNUX68 = function(x) {
    if (x === 165) {
      return null;
    }
    if (x === 189) {
      return null;
    }
    if (x === 200) {
      return null;
    }
  };

  var XUIAmbientNUX69 = function(x) {
    if (x === 166) {
      return XUIAmbientNUX68(165);
    }
    if (x === 190) {
      return XUIAmbientNUX68(189);
    }
    if (x === 201) {
      return XUIAmbientNUX68(200);
    }
  };

  var AdsPEAmbientNUXMegaphone70 = function(x) {
    if (x === 167) {
      return React.createElement(
        'span',
        null,
        React.createElement('span', {}),
        XUIAmbientNUX69(166)
      );
    }
  };

  var AdsPEFilters71 = function(x) {
    if (x === 168) {
      return React.createElement(
        'div',
        {className: '_4rw_'},
        AdsPEFiltersPopover58(144),
        React.createElement('div', {className: '_1eo'}, InputLabel61(147)),
        BUIFilterTokenizer67(164),
        '',
        AdsPEAmbientNUXMegaphone70(167)
      );
    }
  };

  var AdsPEFilterContainer72 = function(x) {
    if (x === 169) {
      return AdsPEFilters71(168);
    }
  };

  var AdsPETablePager73 = function(x) {
    if (x === 172) {
      return null;
    }
  };

  var AdsPECampaignGroupTablePagerContainer74 = function(x) {
    if (x === 173) {
      return AdsPETablePager73(172);
    }
  };

  var AdsPETablePagerContainer75 = function(x) {
    if (x === 174) {
      return AdsPECampaignGroupTablePagerContainer74(173);
    }
  };

  var ReactXUIError76 = function(x) {
    if (x === 181) {
      return AbstractButton3(180);
    }
    if (x === 216) {
      return React.createElement(
        'div',
        {className: '_40bf _2vl4 _1h18'},
        null,
        null,
        React.createElement(
          'div',
          {className: '_2vl9 _1h1f', style: {backgroundColor: '#fff'}},
          React.createElement(
            'div',
            {className: '_2vla _1h1g'},
            React.createElement(
              'div',
              null,
              null,
              React.createElement('textarea', {
                className: '_2vli _2vlj _1h26 _1h27',
                dir: 'auto',
                disabled: undefined,
                id: undefined,
                maxLength: null,
                value: 'Test Campaign',
                onBlur: function() {},
                onChange: function() {},
                onFocus: function() {},
                onKeyDown: function() {},
              }),
              null
            ),
            React.createElement('div', {
              'aria-hidden': 'true',
              className: '_2vlk',
            })
          )
        ),
        null
      );
    }
    if (x === 221) {
      return XUICard94(220);
    }
    if (x === 250) {
      return XUICard94(249);
    }
    if (x === 280) {
      return XUICard94(279);
    }
  };

  var BUIPopoverButton77 = function(x) {
    if (x === 182) {
      return ReactXUIError76(181);
    }
  };

  var BUIDateRangePicker78 = function(x) {
    if (x === 184) {
      return React.createElement('span', null, BUIPopoverButton77(182), [
        Constructor49(183),
      ]);
    }
  };

  var AdsPEStatsRangePicker79 = function(x) {
    if (x === 185) {
      return BUIDateRangePicker78(184);
    }
  };

  var AdsPEStatRange80 = function(x) {
    if (x === 191) {
      return React.createElement(
        'div',
        {className: '_3c5k'},
        React.createElement('span', {className: '_3c5j'}, 'Stats:'),
        React.createElement(
          'span',
          {className: '_3c5l'},
          AdsPEStatsRangePicker79(185),
          XUIButton4(188)
        ),
        [XUIAmbientNUX69(190)]
      );
    }
  };

  var AdsPEStatRangeContainer81 = function(x) {
    if (x === 192) {
      return AdsPEStatRange80(191);
    }
  };

  var AdsPESideTrayTabButton82 = function(x) {
    if (x === 196) {
      return React.createElement(
        'div',
        {className: '_1-ly _59j9 _d9a', onClick: function() {}},
        ReactImage0(195),
        React.createElement('div', {className: '_vf7'}),
        React.createElement('div', {className: '_vf8'})
      );
    }
    if (x === 199) {
      return React.createElement(
        'div',
        {className: ' _1-lz _d9a', onClick: function() {}},
        ReactImage0(198),
        React.createElement('div', {className: '_vf7'}),
        React.createElement('div', {className: '_vf8'})
      );
    }
    if (x === 203) {
      return null;
    }
  };

  var AdsPEEditorTrayTabButton83 = function(x) {
    if (x === 197) {
      return AdsPESideTrayTabButton82(196);
    }
  };

  var AdsPEInsightsTrayTabButton84 = function(x) {
    if (x === 202) {
      return React.createElement(
        'span',
        null,
        AdsPESideTrayTabButton82(199),
        XUIAmbientNUX69(201)
      );
    }
  };

  var AdsPENekoDebuggerTrayTabButton85 = function(x) {
    if (x === 204) {
      return AdsPESideTrayTabButton82(203);
    }
  };

  var AdsPEEditorChildLink86 = function(x) {
    if (x === 211) {
      return React.createElement(
        'div',
        {className: '_3ywr'},
        Link2(208),
        React.createElement('span', {className: '_3ywq'}, '|'),
        Link2(210)
      );
    }
  };

  var AdsPEEditorChildLinkContainer87 = function(x) {
    if (x === 212) {
      return AdsPEEditorChildLink86(211);
    }
  };

  var AdsPEHeaderSection88 = function(x) {
    if (x === 213) {
      return React.createElement(
        'div',
        {className: '_yke'},
        React.createElement('div', {className: '_2x9d _pr-'}),
        XUIText29(205),
        React.createElement(
          'div',
          {className: '_3a-a'},
          React.createElement('div', {className: '_3a-b'}, XUIText29(206))
        ),
        AdsPEEditorChildLinkContainer87(212)
      );
    }
  };

  var AdsPECampaignGroupHeaderSectionContainer89 = function(x) {
    if (x === 214) {
      return AdsPEHeaderSection88(213);
    }
  };

  var AdsEditorLoadingErrors90 = function(x) {
    if (x === 215) {
      return null;
    }
  };

  var AdsTextInput91 = function(x) {
    if (x === 217) {
      return ReactXUIError76(216);
    }
  };

  var BUIFormElement92 = function(x) {
    if (x === 218) {
      return React.createElement(
        'div',
        {className: '_5521 clearfix'},
        React.createElement(
          'div',
          {className: '_5522 _3w5q'},
          React.createElement(
            'label',
            {
              onClick: undefined,
              htmlFor: '1467872040612:1961945894',
              className: '_5523 _3w5r',
            },
            'Campaign Name',
            null
          )
        ),
        React.createElement(
          'div',
          {className: '_5527'},
          React.createElement(
            'div',
            {className: '_5528'},
            React.createElement(
              'span',
              {key: '.0', className: '_40bg', id: '1467872040612:1961945894'},
              AdsTextInput91(217),
              null
            )
          ),
          null
        )
      );
    }
  };

  var BUIForm93 = function(x) {
    if (x === 219) {
      return React.createElement(
        'div',
        {className: '_5ks1 _550r  _550t _550y _3w5n'},
        BUIFormElement92(218)
      );
    }
  };

  var XUICard94 = function(x) {
    if (x === 220) {
      return React.createElement(
        'div',
        {className: '_40bc _12k2 _4-u2  _4-u8'},
        BUIForm93(219)
      );
    }
    if (x === 249) {
      return React.createElement(
        'div',
        {className: '_12k2 _4-u2  _4-u8'},
        AdsCardHeader103(230),
        AdsCardSection108(248)
      );
    }
    if (x === 279) {
      return React.createElement(
        'div',
        {className: '_12k2 _4-u2  _4-u8'},
        AdsCardLeftRightHeader122(278)
      );
    }
  };

  var AdsCard95 = function(x) {
    if (x === 222) {
      return ReactXUIError76(221);
    }
    if (x === 251) {
      return ReactXUIError76(250);
    }
    if (x === 281) {
      return ReactXUIError76(280);
    }
  };

  var AdsEditorNameSection96 = function(x) {
    if (x === 223) {
      return AdsCard95(222);
    }
  };

  var AdsCampaignGroupNameSectionContainer97 = function(x) {
    if (x === 224) {
      return AdsEditorNameSection96(223);
    }
  };

  var _render98 = function(x) {
    if (x === 225) {
      return AdsCampaignGroupNameSectionContainer97(224);
    }
  };

  var AdsPluginWrapper99 = function(x) {
    if (x === 226) {
      return _render98(225);
    }
    if (x === 255) {
      return _render111(254);
    }
    if (x === 258) {
      return _render113(257);
    }
    if (x === 287) {
      return _render127(286);
    }
    if (x === 291) {
      return _render130(290);
    }
  };

  var XUICardHeaderTitle100 = function(x) {
    if (x === 227) {
      return React.createElement(
        'span',
        {className: '_38my'},
        'Campaign Details',
        null,
        React.createElement('span', {className: '_c1c'})
      );
    }
    if (x === 265) {
      return React.createElement(
        'span',
        {className: '_38my'},
        [
          React.createElement(
            'span',
            {key: 1},
            'Campaign ID',
            ': ',
            '98010048849317'
          ),
          React.createElement(
            'div',
            {className: '_5lh9', key: 2},
            FluxContainer_AdsCampaignGroupStatusSwitchContainer_119(264)
          ),
        ],
        null,
        React.createElement('span', {className: '_c1c'})
      );
    }
  };

  var XUICardSection101 = function(x) {
    if (x === 228) {
      return React.createElement(
        'div',
        {className: '_5dw9 _5dwa _4-u3'},
        [XUICardHeaderTitle100(227)],
        undefined,
        undefined,
        React.createElement('div', {className: '_3s3-'})
      );
    }
    if (x === 247) {
      return React.createElement(
        'div',
        {className: '_12jy _4-u3'},
        React.createElement(
          'div',
          {className: '_3-8j'},
          FlexibleBlock105(233),
          FlexibleBlock105(236),
          FlexibleBlock105(246),
          null,
          null
        )
      );
    }
  };

  var XUICardHeader102 = function(x) {
    if (x === 229) {
      return XUICardSection101(228);
    }
  };

  var AdsCardHeader103 = function(x) {
    if (x === 230) {
      return XUICardHeader102(229);
    }
  };

  var AdsLabeledField104 = function(x) {
    if (x === 231) {
      return React.createElement(
        'div',
        {className: '_2oc6 _3bvz', label: 'Objective'},
        React.createElement(
          'label',
          {className: '_4el4 _3qwj _3hy-', htmlFor: undefined},
          'Objective '
        ),
        null,
        React.createElement('div', {className: '_3bv-'})
      );
    }
    if (x === 234) {
      return React.createElement(
        'div',
        {className: '_2oc6 _3bvz', label: 'Buying Type'},
        React.createElement(
          'label',
          {className: '_4el4 _3qwj _3hy-', htmlFor: undefined},
          'Buying Type '
        ),
        null,
        React.createElement('div', {className: '_3bv-'})
      );
    }
    if (x === 240) {
      return React.createElement(
        'div',
        {className: '_2oc6 _3bvz'},
        React.createElement(
          'label',
          {className: '_4el4 _3qwj _3hy-', htmlFor: undefined},
          'Campaign Spending Limit '
        ),
        AdsHelpLink63(239),
        React.createElement('div', {className: '_3bv-'})
      );
    }
  };

  var FlexibleBlock105 = function(x) {
    if (x === 233) {
      return LeftRight21(232);
    }
    if (x === 236) {
      return LeftRight21(235);
    }
    if (x === 246) {
      return LeftRight21(245);
    }
  };

  var AdsBulkCampaignSpendCapField106 = function(x) {
    if (x === 243) {
      return React.createElement(
        'div',
        {className: '_33dv'},
        '',
        Link2(242),
        ' (optional)'
      );
    }
  };

  var FluxContainer_AdsCampaignGroupSpendCapContainer_107 = function(x) {
    if (x === 244) {
      return AdsBulkCampaignSpendCapField106(243);
    }
  };

  var AdsCardSection108 = function(x) {
    if (x === 248) {
      return XUICardSection101(247);
    }
  };

  var AdsEditorCampaignGroupDetailsSection109 = function(x) {
    if (x === 252) {
      return AdsCard95(251);
    }
  };

  var AdsEditorCampaignGroupDetailsSectionContainer110 = function(x) {
    if (x === 253) {
      return AdsEditorCampaignGroupDetailsSection109(252);
    }
  };

  var _render111 = function(x) {
    if (x === 254) {
      return AdsEditorCampaignGroupDetailsSectionContainer110(253);
    }
  };

  var FluxContainer_AdsEditorToplineDetailsSectionContainer_112 = function(x) {
    if (x === 256) {
      return null;
    }
  };

  var _render113 = function(x) {
    if (x === 257) {
      return FluxContainer_AdsEditorToplineDetailsSectionContainer_112(256);
    }
  };

  var AdsStickyArea114 = function(x) {
    if (x === 259) {
      return React.createElement(
        'div',
        {},
        React.createElement('div', {onWheel: function() {}})
      );
    }
    if (x === 292) {
      return React.createElement(
        'div',
        {},
        React.createElement('div', {onWheel: function() {}}, [
          React.createElement(
            'div',
            {key: 'campaign_group_errors_section98010048849317'},
            AdsPluginWrapper99(291)
          ),
        ])
      );
    }
  };

  var FluxContainer_AdsEditorColumnContainer_115 = function(x) {
    if (x === 260) {
      return React.createElement(
        'div',
        null,
        [
          React.createElement(
            'div',
            {key: 'campaign_group_name_section98010048849317'},
            AdsPluginWrapper99(226)
          ),
          React.createElement(
            'div',
            {key: 'campaign_group_basic_section98010048849317'},
            AdsPluginWrapper99(255)
          ),
          React.createElement(
            'div',
            {key: 'campaign_group_topline_section98010048849317'},
            AdsPluginWrapper99(258)
          ),
        ],
        AdsStickyArea114(259)
      );
    }
    if (x === 293) {
      return React.createElement(
        'div',
        null,
        [
          React.createElement(
            'div',
            {key: 'campaign_group_navigation_section98010048849317'},
            AdsPluginWrapper99(287)
          ),
        ],
        AdsStickyArea114(292)
      );
    }
  };

  var BUISwitch116 = function(x) {
    if (x === 261) {
      return React.createElement(
        'div',
        {
          'data-hover': 'tooltip',
          'data-tooltip-content':
            'Currently active. Click this switch to deactivate it.',
          'data-tooltip-position': 'below',
          disabled: false,
          value: true,
          onToggle: function() {},
          className: '_128j _128k _128n',
          role: 'checkbox',
          'aria-checked': 'true',
        },
        React.createElement(
          'div',
          {
            className: '_128o',
            onClick: function() {},
            onKeyDown: function() {},
            onMouseDown: function() {},
            tabIndex: '0',
          },
          React.createElement('div', {className: '_128p'})
        ),
        null
      );
    }
  };

  var AdsStatusSwitchInternal117 = function(x) {
    if (x === 262) {
      return BUISwitch116(261);
    }
  };

  var AdsStatusSwitch118 = function(x) {
    if (x === 263) {
      return AdsStatusSwitchInternal117(262);
    }
  };

  var FluxContainer_AdsCampaignGroupStatusSwitchContainer_119 = function(x) {
    if (x === 264) {
      return AdsStatusSwitch118(263);
    }
  };

  var AdsLinksMenu120 = function(x) {
    if (x === 275) {
      return ReactPopoverMenu20(274);
    }
  };

  var FluxContainer_AdsPluginizedLinksMenuContainer_121 = function(x) {
    if (x === 276) {
      return React.createElement('div', null, null, AdsLinksMenu120(275));
    }
  };

  var AdsCardLeftRightHeader122 = function(x) {
    if (x === 278) {
      return LeftRight21(277);
    }
  };

  var AdsPEIDSection123 = function(x) {
    if (x === 282) {
      return AdsCard95(281);
    }
  };

  var FluxContainer_AdsPECampaignGroupIDSectionContainer_124 = function(x) {
    if (x === 283) {
      return AdsPEIDSection123(282);
    }
  };

  var DeferredComponent125 = function(x) {
    if (x === 284) {
      return FluxContainer_AdsPECampaignGroupIDSectionContainer_124(283);
    }
  };

  var BootloadedComponent126 = function(x) {
    if (x === 285) {
      return DeferredComponent125(284);
    }
  };

  var _render127 = function(x) {
    if (x === 286) {
      return BootloadedComponent126(285);
    }
  };

  var AdsEditorErrorsCard128 = function(x) {
    if (x === 288) {
      return null;
    }
  };

  var FluxContainer_FunctionalContainer_129 = function(x) {
    if (x === 289) {
      return AdsEditorErrorsCard128(288);
    }
  };

  var _render130 = function(x) {
    if (x === 290) {
      return FluxContainer_FunctionalContainer_129(289);
    }
  };

  var AdsEditorMultiColumnLayout131 = function(x) {
    if (x === 294) {
      return React.createElement(
        'div',
        {className: '_psh'},
        React.createElement(
          'div',
          {className: '_3cc0'},
          React.createElement(
            'div',
            null,
            AdsEditorLoadingErrors90(215),
            React.createElement(
              'div',
              {className: '_3ms3'},
              React.createElement(
                'div',
                {className: '_3ms4'},
                FluxContainer_AdsEditorColumnContainer_115(260)
              ),
              React.createElement(
                'div',
                {className: '_3pvg'},
                FluxContainer_AdsEditorColumnContainer_115(293)
              )
            )
          )
        )
      );
    }
  };

  var AdsPECampaignGroupEditor132 = function(x) {
    if (x === 295) {
      return React.createElement(
        'div',
        null,
        AdsPECampaignGroupHeaderSectionContainer89(214),
        AdsEditorMultiColumnLayout131(294)
      );
    }
  };

  var AdsPECampaignGroupEditorContainer133 = function(x) {
    if (x === 296) {
      return AdsPECampaignGroupEditor132(295);
    }
  };

  var AdsPESideTrayTabContent134 = function(x) {
    if (x === 297) {
      return React.createElement(
        'div',
        {className: '_1o_8 _44ra _5cyn'},
        AdsPECampaignGroupEditorContainer133(296)
      );
    }
  };

  var AdsPEEditorTrayTabContentContainer135 = function(x) {
    if (x === 298) {
      return AdsPESideTrayTabContent134(297);
    }
  };

  var AdsPEMultiTabDrawer136 = function(x) {
    if (x === 299) {
      return React.createElement(
        'div',
        {className: '_2kev _2kex'},
        React.createElement(
          'div',
          {className: '_5yno'},
          AdsPEEditorTrayTabButton83(197),
          AdsPEInsightsTrayTabButton84(202),
          AdsPENekoDebuggerTrayTabButton85(204)
        ),
        React.createElement(
          'div',
          {className: '_5ynn'},
          AdsPEEditorTrayTabContentContainer135(298),
          null
        )
      );
    }
  };

  var FluxContainer_AdsPEMultiTabDrawerContainer_137 = function(x) {
    if (x === 300) {
      return AdsPEMultiTabDrawer136(299);
    }
  };

  var AdsPESimpleOrganizer138 = function(x) {
    if (x === 309) {
      return React.createElement(
        'div',
        {className: '_tm2'},
        XUIButton4(304),
        XUIButton4(306),
        XUIButton4(308)
      );
    }
  };

  var AdsPEOrganizerContainer139 = function(x) {
    if (x === 310) {
      return React.createElement('div', null, AdsPESimpleOrganizer138(309));
    }
  };

  var FixedDataTableColumnResizeHandle140 = function(x) {
    if (x === 313) {
      return React.createElement(
        'div',
        {
          className: '_3487 _3488 _3489',
          style: {width: 0, height: 25, left: 0},
        },
        React.createElement('div', {className: '_348a', style: {height: 25}})
      );
    }
  };

  var AdsPETableHeader141 = function(x) {
    if (x === 315) {
      return React.createElement(
        'div',
        {className: '_1cig _1ksv _1vd7 _4h2r', id: undefined},
        ReactImage0(314),
        React.createElement('span', {className: '_1cid'}, 'Campaigns')
      );
    }
    if (x === 320) {
      return React.createElement(
        'div',
        {className: '_1cig _1vd7 _4h2r', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Performance')
      );
    }
    if (x === 323) {
      return React.createElement(
        'div',
        {className: '_1cig _1vd7 _4h2r', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Overview')
      );
    }
    if (x === 326) {
      return React.createElement(
        'div',
        {className: '_1cig _1vd7 _4h2r', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Toplines')
      );
    }
    if (x === 329) {
      return React.createElement('div', {
        className: '_1cig _1vd7 _4h2r',
        id: undefined,
      });
    }
    if (x === 340) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Campaign Name')
      );
    }
    if (x === 346) {
      return React.createElement(
        'div',
        {
          className: '_1cig _25fg',
          id: undefined,
          'data-tooltip-content': 'Changed',
          'data-hover': 'tooltip',
        },
        ReactImage0(345),
        null
      );
    }
    if (x === 352) {
      return React.createElement(
        'div',
        {
          className: '_1cig _25fg',
          id: 'ads_pe_table_error_header',
          'data-tooltip-content': 'Errors',
          'data-hover': 'tooltip',
        },
        ReactImage0(351),
        null
      );
    }
    if (x === 357) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Status')
      );
    }
    if (x === 362) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Delivery')
      );
    }
    if (x === 369) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Results')
      );
    }
    if (x === 374) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Cost')
      );
    }
    if (x === 379) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Reach')
      );
    }
    if (x === 384) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Impressions')
      );
    }
    if (x === 389) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Clicks')
      );
    }
    if (x === 394) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Avg. CPM')
      );
    }
    if (x === 399) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Avg. CPC')
      );
    }
    if (x === 404) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'CTR %')
      );
    }
    if (x === 409) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Spent')
      );
    }
    if (x === 414) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Objective')
      );
    }
    if (x === 419) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Buying Type')
      );
    }
    if (x === 424) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Campaign ID')
      );
    }
    if (x === 429) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Start')
      );
    }
    if (x === 434) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'End')
      );
    }
    if (x === 439) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Date created')
      );
    }
    if (x === 444) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Date last edited')
      );
    }
    if (x === 449) {
      return React.createElement(
        'div',
        {className: '_1cig _25fg _4h2r', id: undefined},
        null,
        React.createElement('span', {className: '_1cid'}, 'Tags')
      );
    }
    if (x === 452) {
      return React.createElement('div', {
        className: '_1cig _25fg _4h2r',
        id: undefined,
      });
    }
  };

  var TransitionCell142 = function(x) {
    if (x === 316) {
      return React.createElement(
        'div',
        {
          label: 'Campaigns',
          height: 40,
          width: 721,
          className: '_4lgc _4h2u',
          style: {height: 40, width: 721},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(315)
          )
        )
      );
    }
    if (x === 321) {
      return React.createElement(
        'div',
        {
          label: 'Performance',
          height: 40,
          width: 798,
          className: '_4lgc _4h2u',
          style: {height: 40, width: 798},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(320)
          )
        )
      );
    }
    if (x === 324) {
      return React.createElement(
        'div',
        {
          label: 'Overview',
          height: 40,
          width: 1022,
          className: '_4lgc _4h2u',
          style: {height: 40, width: 1022},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(323)
          )
        )
      );
    }
    if (x === 327) {
      return React.createElement(
        'div',
        {
          label: 'Toplines',
          height: 40,
          width: 0,
          className: '_4lgc _4h2u',
          style: {height: 40, width: 0},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(326)
          )
        )
      );
    }
    if (x === 330) {
      return React.createElement(
        'div',
        {
          label: '',
          height: 40,
          width: 25,
          className: '_4lgc _4h2u',
          style: {height: 40, width: 25},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(329)
          )
        )
      );
    }
    if (x === 338) {
      return React.createElement(
        'div',
        {
          label: undefined,
          width: 42,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 42},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            XUICheckboxInput60(337)
          )
        )
      );
    }
    if (x === 343) {
      return React.createElement(
        'div',
        {
          label: 'Campaign Name',
          width: 400,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 400},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(342)
          )
        )
      );
    }
    if (x === 349) {
      return React.createElement(
        'div',
        {
          label: undefined,
          width: 33,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 33},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(348)
          )
        )
      );
    }
    if (x === 355) {
      return React.createElement(
        'div',
        {
          label: undefined,
          width: 36,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 36},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(354)
          )
        )
      );
    }
    if (x === 360) {
      return React.createElement(
        'div',
        {
          label: 'Status',
          width: 60,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 60},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(359)
          )
        )
      );
    }
    if (x === 365) {
      return React.createElement(
        'div',
        {
          label: 'Delivery',
          width: 150,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 150},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(364)
          )
        )
      );
    }
    if (x === 372) {
      return React.createElement(
        'div',
        {
          label: 'Results',
          width: 140,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 140},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(371)
          )
        )
      );
    }
    if (x === 377) {
      return React.createElement(
        'div',
        {
          label: 'Cost',
          width: 140,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 140},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(376)
          )
        )
      );
    }
    if (x === 382) {
      return React.createElement(
        'div',
        {
          label: 'Reach',
          width: 80,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 80},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(381)
          )
        )
      );
    }
    if (x === 387) {
      return React.createElement(
        'div',
        {
          label: 'Impressions',
          width: 80,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 80},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(386)
          )
        )
      );
    }
    if (x === 392) {
      return React.createElement(
        'div',
        {
          label: 'Clicks',
          width: 60,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 60},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(391)
          )
        )
      );
    }
    if (x === 397) {
      return React.createElement(
        'div',
        {
          label: 'Avg. CPM',
          width: 80,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 80},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(396)
          )
        )
      );
    }
    if (x === 402) {
      return React.createElement(
        'div',
        {
          label: 'Avg. CPC',
          width: 78,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 78},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(401)
          )
        )
      );
    }
    if (x === 407) {
      return React.createElement(
        'div',
        {
          label: 'CTR %',
          width: 70,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 70},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(406)
          )
        )
      );
    }
    if (x === 412) {
      return React.createElement(
        'div',
        {
          label: 'Spent',
          width: 70,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 70},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(411)
          )
        )
      );
    }
    if (x === 417) {
      return React.createElement(
        'div',
        {
          label: 'Objective',
          width: 200,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 200},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(416)
          )
        )
      );
    }
    if (x === 422) {
      return React.createElement(
        'div',
        {
          label: 'Buying Type',
          width: 100,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 100},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(421)
          )
        )
      );
    }
    if (x === 427) {
      return React.createElement(
        'div',
        {
          label: 'Campaign ID',
          width: 120,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 120},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(426)
          )
        )
      );
    }
    if (x === 432) {
      return React.createElement(
        'div',
        {
          label: 'Start',
          width: 113,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 113},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(431)
          )
        )
      );
    }
    if (x === 437) {
      return React.createElement(
        'div',
        {
          label: 'End',
          width: 113,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 113},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(436)
          )
        )
      );
    }
    if (x === 442) {
      return React.createElement(
        'div',
        {
          label: 'Date created',
          width: 113,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 113},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(441)
          )
        )
      );
    }
    if (x === 447) {
      return React.createElement(
        'div',
        {
          label: 'Date last edited',
          width: 113,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 113},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            FixedDataTableSortableHeader149(446)
          )
        )
      );
    }
    if (x === 450) {
      return React.createElement(
        'div',
        {
          label: 'Tags',
          width: 150,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 150},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(449)
          )
        )
      );
    }
    if (x === 453) {
      return React.createElement(
        'div',
        {
          label: '',
          width: 25,
          className: '_4lgc _4h2u',
          height: 25,
          style: {height: 25, width: 25},
        },
        React.createElement(
          'div',
          {className: '_4lgd _4h2w'},
          React.createElement(
            'div',
            {className: '_4lge _4h2x'},
            AdsPETableHeader141(452)
          )
        )
      );
    }
  };

  var FixedDataTableCell143 = function(x) {
    if (x === 317) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 40, width: 721, left: 0}},
        undefined,
        TransitionCell142(316)
      );
    }
    if (x === 322) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 40, width: 798, left: 0}},
        undefined,
        TransitionCell142(321)
      );
    }
    if (x === 325) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 40, width: 1022, left: 798}},
        undefined,
        TransitionCell142(324)
      );
    }
    if (x === 328) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 40, width: 0, left: 1820}},
        undefined,
        TransitionCell142(327)
      );
    }
    if (x === 331) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 40, width: 25, left: 1820}},
        undefined,
        TransitionCell142(330)
      );
    }
    if (x === 339) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg6 _4h2m',
          style: {height: 25, width: 42, left: 0},
        },
        undefined,
        TransitionCell142(338)
      );
    }
    if (x === 344) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 400, left: 42}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(343)
      );
    }
    if (x === 350) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 33, left: 442}},
        undefined,
        TransitionCell142(349)
      );
    }
    if (x === 356) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 36, left: 475}},
        undefined,
        TransitionCell142(355)
      );
    }
    if (x === 361) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 60, left: 511}},
        undefined,
        TransitionCell142(360)
      );
    }
    if (x === 366) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 150, left: 571}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(365)
      );
    }
    if (x === 373) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 140, left: 0},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(372)
      );
    }
    if (x === 378) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 140, left: 140},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(377)
      );
    }
    if (x === 383) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 80, left: 280},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(382)
      );
    }
    if (x === 388) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 80, left: 360},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(387)
      );
    }
    if (x === 393) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 60, left: 440},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(392)
      );
    }
    if (x === 398) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 80, left: 500},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(397)
      );
    }
    if (x === 403) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 78, left: 580},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(402)
      );
    }
    if (x === 408) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 70, left: 658},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(407)
      );
    }
    if (x === 413) {
      return React.createElement(
        'div',
        {
          className: '_4lg0 _4lg5 _4h2p _4h2m',
          style: {height: 25, width: 70, left: 728},
        },
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(412)
      );
    }
    if (x === 418) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 200, left: 798}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(417)
      );
    }
    if (x === 423) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 100, left: 998}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(422)
      );
    }
    if (x === 428) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 120, left: 1098}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(427)
      );
    }
    if (x === 433) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 113, left: 1218}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(432)
      );
    }
    if (x === 438) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 113, left: 1331}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(437)
      );
    }
    if (x === 443) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 113, left: 1444}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(442)
      );
    }
    if (x === 448) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 113, left: 1557}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(447)
      );
    }
    if (x === 451) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 150, left: 1670}},
        React.createElement(
          'div',
          {className: '_4lg9', style: {height: 25}, onMouseDown: function() {}},
          React.createElement('div', {
            className: '_4lga _4lgb',
            style: {height: 25},
          })
        ),
        TransitionCell142(450)
      );
    }
    if (x === 454) {
      return React.createElement(
        'div',
        {className: '_4lg0 _4h2m', style: {height: 25, width: 25, left: 1820}},
        undefined,
        TransitionCell142(453)
      );
    }
  };

  var FixedDataTableCellGroupImpl144 = function(x) {
    if (x === 318) {
      return React.createElement(
        'div',
        {
          className: '_3pzj',
          style: {
            height: 40,
            position: 'absolute',
            width: 721,
            zIndex: 2,
            transform: 'translate3d(0px,0px,0)',
            backfaceVisibility: 'hidden',
          },
        },
        FixedDataTableCell143(317)
      );
    }
    if (x === 332) {
      return React.createElement(
        'div',
        {
          className: '_3pzj',
          style: {
            height: 40,
            position: 'absolute',
            width: 1845,
            zIndex: 0,
            transform: 'translate3d(0px,0px,0)',
            backfaceVisibility: 'hidden',
          },
        },
        FixedDataTableCell143(322),
        FixedDataTableCell143(325),
        FixedDataTableCell143(328),
        FixedDataTableCell143(331)
      );
    }
    if (x === 367) {
      return React.createElement(
        'div',
        {
          className: '_3pzj',
          style: {
            height: 25,
            position: 'absolute',
            width: 721,
            zIndex: 2,
            transform: 'translate3d(0px,0px,0)',
            backfaceVisibility: 'hidden',
          },
        },
        FixedDataTableCell143(339),
        FixedDataTableCell143(344),
        FixedDataTableCell143(350),
        FixedDataTableCell143(356),
        FixedDataTableCell143(361),
        FixedDataTableCell143(366)
      );
    }
    if (x === 455) {
      return React.createElement(
        'div',
        {
          className: '_3pzj',
          style: {
            height: 25,
            position: 'absolute',
            width: 1845,
            zIndex: 0,
            transform: 'translate3d(0px,0px,0)',
            backfaceVisibility: 'hidden',
          },
        },
        FixedDataTableCell143(373),
        FixedDataTableCell143(378),
        FixedDataTableCell143(383),
        FixedDataTableCell143(388),
        FixedDataTableCell143(393),
        FixedDataTableCell143(398),
        FixedDataTableCell143(403),
        FixedDataTableCell143(408),
        FixedDataTableCell143(413),
        FixedDataTableCell143(418),
        FixedDataTableCell143(423),
        FixedDataTableCell143(428),
        FixedDataTableCell143(433),
        FixedDataTableCell143(438),
        FixedDataTableCell143(443),
        FixedDataTableCell143(448),
        FixedDataTableCell143(451),
        FixedDataTableCell143(454)
      );
    }
  };

  var FixedDataTableCellGroup145 = function(x) {
    if (x === 319) {
      return React.createElement(
        'div',
        {style: {height: 40, left: 0}, className: '_3pzk'},
        FixedDataTableCellGroupImpl144(318)
      );
    }
    if (x === 333) {
      return React.createElement(
        'div',
        {style: {height: 40, left: 721}, className: '_3pzk'},
        FixedDataTableCellGroupImpl144(332)
      );
    }
    if (x === 368) {
      return React.createElement(
        'div',
        {style: {height: 25, left: 0}, className: '_3pzk'},
        FixedDataTableCellGroupImpl144(367)
      );
    }
    if (x === 456) {
      return React.createElement(
        'div',
        {style: {height: 25, left: 721}, className: '_3pzk'},
        FixedDataTableCellGroupImpl144(455)
      );
    }
  };

  var FixedDataTableRowImpl146 = function(x) {
    if (x === 334) {
      return React.createElement(
        'div',
        {
          className: '_1gd4 _4li _52no _3h1a _1mib',
          onClick: null,
          onDoubleClick: null,
          onMouseDown: null,
          onMouseEnter: null,
          onMouseLeave: null,
          style: {width: 1209, height: 40},
        },
        React.createElement(
          'div',
          {className: '_1gd5'},
          FixedDataTableCellGroup145(319),
          FixedDataTableCellGroup145(333),
          React.createElement('div', {
            className: '_1gd6 _1gd8',
            style: {left: 721, height: 40},
          })
        )
      );
    }
    if (x === 457) {
      return React.createElement(
        'div',
        {
          className: '_1gd4 _4li _3h1a _1mib',
          onClick: null,
          onDoubleClick: null,
          onMouseDown: null,
          onMouseEnter: null,
          onMouseLeave: null,
          style: {width: 1209, height: 25},
        },
        React.createElement(
          'div',
          {className: '_1gd5'},
          FixedDataTableCellGroup145(368),
          FixedDataTableCellGroup145(456),
          React.createElement('div', {
            className: '_1gd6 _1gd8',
            style: {left: 721, height: 25},
          })
        )
      );
    }
  };

  var FixedDataTableRow147 = function(x) {
    if (x === 335) {
      return React.createElement(
        'div',
        {
          style: {
            width: 1209,
            height: 40,
            zIndex: 1,
            transform: 'translate3d(0px,0px,0)',
            backfaceVisibility: 'hidden',
          },
          className: '_1gda',
        },
        FixedDataTableRowImpl146(334)
      );
    }
    if (x === 458) {
      return React.createElement(
        'div',
        {
          style: {
            width: 1209,
            height: 25,
            zIndex: 1,
            transform: 'translate3d(0px,40px,0)',
            backfaceVisibility: 'hidden',
          },
          className: '_1gda',
        },
        FixedDataTableRowImpl146(457)
      );
    }
  };

  var FixedDataTableAbstractSortableHeader148 = function(x) {
    if (x === 341) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(340)
        )
      );
    }
    if (x === 347) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _1kst _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(346)
        )
      );
    }
    if (x === 353) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _1kst _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(352)
        )
      );
    }
    if (x === 358) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(357)
        )
      );
    }
    if (x === 363) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _54_9 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(362)
        )
      );
    }
    if (x === 370) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(369)
        )
      );
    }
    if (x === 375) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(374)
        )
      );
    }
    if (x === 380) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(379)
        )
      );
    }
    if (x === 385) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(384)
        )
      );
    }
    if (x === 390) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(389)
        )
      );
    }
    if (x === 395) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(394)
        )
      );
    }
    if (x === 400) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(399)
        )
      );
    }
    if (x === 405) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(404)
        )
      );
    }
    if (x === 410) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(409)
        )
      );
    }
    if (x === 415) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(414)
        )
      );
    }
    if (x === 420) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(419)
        )
      );
    }
    if (x === 425) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(424)
        )
      );
    }
    if (x === 430) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(429)
        )
      );
    }
    if (x === 435) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(434)
        )
      );
    }
    if (x === 440) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(439)
        )
      );
    }
    if (x === 445) {
      return React.createElement(
        'div',
        {onClick: function() {}, className: '_54_8 _4h2r _2wzx'},
        React.createElement(
          'div',
          {className: '_2eq6'},
          null,
          AdsPETableHeader141(444)
        )
      );
    }
  };

  var FixedDataTableSortableHeader149 = function(x) {
    if (x === 342) {
      return FixedDataTableAbstractSortableHeader148(341);
    }
    if (x === 348) {
      return FixedDataTableAbstractSortableHeader148(347);
    }
    if (x === 354) {
      return FixedDataTableAbstractSortableHeader148(353);
    }
    if (x === 359) {
      return FixedDataTableAbstractSortableHeader148(358);
    }
    if (x === 364) {
      return FixedDataTableAbstractSortableHeader148(363);
    }
    if (x === 371) {
      return FixedDataTableAbstractSortableHeader148(370);
    }
    if (x === 376) {
      return FixedDataTableAbstractSortableHeader148(375);
    }
    if (x === 381) {
      return FixedDataTableAbstractSortableHeader148(380);
    }
    if (x === 386) {
      return FixedDataTableAbstractSortableHeader148(385);
    }
    if (x === 391) {
      return FixedDataTableAbstractSortableHeader148(390);
    }
    if (x === 396) {
      return FixedDataTableAbstractSortableHeader148(395);
    }
    if (x === 401) {
      return FixedDataTableAbstractSortableHeader148(400);
    }
    if (x === 406) {
      return FixedDataTableAbstractSortableHeader148(405);
    }
    if (x === 411) {
      return FixedDataTableAbstractSortableHeader148(410);
    }
    if (x === 416) {
      return FixedDataTableAbstractSortableHeader148(415);
    }
    if (x === 421) {
      return FixedDataTableAbstractSortableHeader148(420);
    }
    if (x === 426) {
      return FixedDataTableAbstractSortableHeader148(425);
    }
    if (x === 431) {
      return FixedDataTableAbstractSortableHeader148(430);
    }
    if (x === 436) {
      return FixedDataTableAbstractSortableHeader148(435);
    }
    if (x === 441) {
      return FixedDataTableAbstractSortableHeader148(440);
    }
    if (x === 446) {
      return FixedDataTableAbstractSortableHeader148(445);
    }
  };

  var FixedDataTableBufferedRows150 = function(x) {
    if (x === 459) {
      return React.createElement('div', {
        style: {
          position: 'absolute',
          pointerEvents: 'auto',
          transform: 'translate3d(0px,65px,0)',
          backfaceVisibility: 'hidden',
        },
      });
    }
  };

  var Scrollbar151 = function(x) {
    if (x === 460) {
      return null;
    }
    if (x === 461) {
      return React.createElement(
        'div',
        {
          onFocus: function() {},
          onBlur: function() {},
          onKeyDown: function() {},
          onMouseDown: function() {},
          onWheel: function() {},
          className: '_1t0r _1t0t _4jdr _1t0u',
          style: {width: 1209, zIndex: 99},
          tabIndex: 0,
        },
        React.createElement('div', {
          className: '_1t0w _1t0y _1t0_',
          style: {
            width: 561.6340607950117,
            transform: 'translate3d(4px,0px,0)',
            backfaceVisibility: 'hidden',
          },
        })
      );
    }
  };

  var HorizontalScrollbar152 = function(x) {
    if (x === 462) {
      return React.createElement(
        'div',
        {className: '_3h1k _3h1m', style: {height: 15, width: 1209}},
        React.createElement(
          'div',
          {
            style: {
              height: 15,
              position: 'absolute',
              overflow: 'hidden',
              width: 1209,
              transform: 'translate3d(0px,0px,0)',
              backfaceVisibility: 'hidden',
            },
          },
          Scrollbar151(461)
        )
      );
    }
  };

  var FixedDataTable153 = function(x) {
    if (x === 463) {
      return React.createElement(
        'div',
        {
          className: '_3h1i _1mie',
          onWheel: function() {},
          style: {height: 25, width: 1209},
        },
        React.createElement(
          'div',
          {className: '_3h1j', style: {height: 8, width: 1209}},
          FixedDataTableColumnResizeHandle140(313),
          FixedDataTableRow147(335),
          FixedDataTableRow147(458),
          FixedDataTableBufferedRows150(459),
          null,
          undefined,
          React.createElement('div', {
            className: '_3h1e _3h1h',
            style: {top: 8},
          })
        ),
        Scrollbar151(460),
        HorizontalScrollbar152(462)
      );
    }
  };

  var TransitionTable154 = function(x) {
    if (x === 464) {
      return FixedDataTable153(463);
    }
  };

  var AdsSelectableFixedDataTable155 = function(x) {
    if (x === 465) {
      return React.createElement(
        'div',
        {className: '_5hht'},
        TransitionTable154(464)
      );
    }
  };

  var AdsDataTableKeyboardSupportDecorator156 = function(x) {
    if (x === 466) {
      return React.createElement(
        'div',
        {className: '_5d6f', tabIndex: '0', onKeyDown: function() {}},
        AdsSelectableFixedDataTable155(465)
      );
    }
  };

  var AdsEditableDataTableDecorator157 = function(x) {
    if (x === 467) {
      return React.createElement(
        'div',
        {onCopy: function() {}},
        AdsDataTableKeyboardSupportDecorator156(466)
      );
    }
  };

  var AdsPEDataTableContainer158 = function(x) {
    if (x === 468) {
      return React.createElement(
        'div',
        {className: '_35l_ _1hr clearfix'},
        null,
        null,
        null,
        AdsEditableDataTableDecorator157(467)
      );
    }
  };

  var AdsPECampaignGroupTableContainer159 = function(x) {
    if (x === 470) {
      return ResponsiveBlock37(469);
    }
  };

  var AdsPEManageAdsPaneContainer160 = function(x) {
    if (x === 473) {
      return React.createElement(
        'div',
        null,
        AdsErrorBoundary10(65),
        React.createElement(
          'div',
          {className: '_2uty'},
          AdsErrorBoundary10(125)
        ),
        React.createElement(
          'div',
          {className: '_2utx _21oc'},
          AdsErrorBoundary10(171),
          React.createElement(
            'div',
            {className: '_41tu'},
            AdsErrorBoundary10(176),
            AdsErrorBoundary10(194)
          )
        ),
        React.createElement(
          'div',
          {className: '_2utz', style: {height: 25}},
          AdsErrorBoundary10(302),
          React.createElement(
            'div',
            {className: '_2ut-'},
            AdsErrorBoundary10(312)
          ),
          React.createElement(
            'div',
            {className: '_2ut_'},
            AdsErrorBoundary10(472)
          )
        )
      );
    }
  };

  var AdsPEContentContainer161 = function(x) {
    if (x === 474) {
      return AdsPEManageAdsPaneContainer160(473);
    }
  };

  var FluxContainer_AdsPEWorkspaceContainer_162 = function(x) {
    if (x === 477) {
      return React.createElement(
        'div',
        {className: '_49wu', style: {height: 177, top: 43, width: 1306}},
        ResponsiveBlock37(62, '0'),
        AdsErrorBoundary10(476, '1'),
        null
      );
    }
  };

  var FluxContainer_AdsSessionExpiredDialogContainer_163 = function(x) {
    if (x === 478) {
      return null;
    }
  };

  var FluxContainer_AdsPEUploadDialogLazyContainer_164 = function(x) {
    if (x === 479) {
      return null;
    }
  };

  var FluxContainer_DialogContainer_165 = function(x) {
    if (x === 480) {
      return null;
    }
  };

  var AdsBugReportContainer166 = function(x) {
    if (x === 481) {
      return React.createElement('span', null);
    }
  };

  var AdsPEAudienceSplittingDialog167 = function(x) {
    if (x === 482) {
      return null;
    }
  };

  var AdsPEAudienceSplittingDialogContainer168 = function(x) {
    if (x === 483) {
      return React.createElement(
        'div',
        null,
        AdsPEAudienceSplittingDialog167(482)
      );
    }
  };

  var FluxContainer_AdsRuleDialogBootloadContainer_169 = function(x) {
    if (x === 484) {
      return null;
    }
  };

  var FluxContainer_AdsPECFTrayContainer_170 = function(x) {
    if (x === 485) {
      return null;
    }
  };

  var FluxContainer_AdsPEDeleteDraftContainer_171 = function(x) {
    if (x === 486) {
      return null;
    }
  };

  var FluxContainer_AdsPEInitialDraftPublishDialogContainer_172 = function(x) {
    if (x === 487) {
      return null;
    }
  };

  var FluxContainer_AdsPEReachFrequencyStatusTransitionDialogBootloadContainer_173 = function(
    x
  ) {
    if (x === 488) {
      return null;
    }
  };

  var FluxContainer_AdsPEPurgeArchiveDialogContainer_174 = function(x) {
    if (x === 489) {
      return null;
    }
  };

  var AdsPECreateDialogContainer175 = function(x) {
    if (x === 490) {
      return React.createElement('span', null);
    }
  };

  var FluxContainer_AdsPEModalStatusContainer_176 = function(x) {
    if (x === 491) {
      return null;
    }
  };

  var FluxContainer_AdsBrowserExtensionErrorDialogContainer_177 = function(x) {
    if (x === 492) {
      return null;
    }
  };

  var FluxContainer_AdsPESortByErrorTipContainer_178 = function(x) {
    if (x === 493) {
      return null;
    }
  };

  var LeadDownloadDialogSelector179 = function(x) {
    if (x === 494) {
      return null;
    }
  };

  var FluxContainer_AdsPELeadDownloadDialogContainerClass_180 = function(x) {
    if (x === 495) {
      return LeadDownloadDialogSelector179(494);
    }
  };

  var AdsPEContainer181 = function(x) {
    if (x === 496) {
      return React.createElement(
        'div',
        {id: 'ads_pe_container'},
        FluxContainer_AdsPETopNavContainer_26(41),
        null,
        FluxContainer_AdsPEWorkspaceContainer_162(477),
        FluxContainer_AdsSessionExpiredDialogContainer_163(478),
        FluxContainer_AdsPEUploadDialogLazyContainer_164(479),
        FluxContainer_DialogContainer_165(480),
        AdsBugReportContainer166(481),
        AdsPEAudienceSplittingDialogContainer168(483),
        FluxContainer_AdsRuleDialogBootloadContainer_169(484),
        FluxContainer_AdsPECFTrayContainer_170(485),
        React.createElement(
          'span',
          null,
          FluxContainer_AdsPEDeleteDraftContainer_171(486),
          FluxContainer_AdsPEInitialDraftPublishDialogContainer_172(487),
          FluxContainer_AdsPEReachFrequencyStatusTransitionDialogBootloadContainer_173(
            488
          )
        ),
        FluxContainer_AdsPEPurgeArchiveDialogContainer_174(489),
        AdsPECreateDialogContainer175(490),
        FluxContainer_AdsPEModalStatusContainer_176(491),
        FluxContainer_AdsBrowserExtensionErrorDialogContainer_177(492),
        FluxContainer_AdsPESortByErrorTipContainer_178(493),
        FluxContainer_AdsPELeadDownloadDialogContainerClass_180(495),
        React.createElement('div', {id: 'web_ads_guidance_tips'})
      );
    }
  };

  var Benchmark = function(x) {
    if (x === undefined) {
      return AdsPEContainer181(496);
    }
  };

  var app = document.getElementById('app');

  window.render = function render() {
    ReactDOM.render(Benchmark(), app);
  };
})();
